"""統一ハイブリッド戦略V3の日内重複テスト"""
import sys
from collections import defaultdict
from src.infrastructure.config.path_manager import PathManager
from src.infrastructure.repositories.csv_repository import CSVRepository
from src.infrastructure.config.constraint_loader import ConstraintLoader
from src.domain.services.core.unified_constraint_system import UnifiedConstraintSystem
from src.application.services.schedule_generation_service import ScheduleGenerationService
from src.application.use_cases.generate_schedule import GenerateScheduleUseCase
from src.application.use_cases.request_models import GenerateScheduleRequest

def analyze_daily_duplicates(output_path="/Users/hayashimitsuhiro/Desktop/timetable_v5/data/output/output.csv"):
    """日内重複を分析"""
    import csv
    
    # スケジュールを読み込み
    daily_subjects = defaultdict(list)  # (class, day) -> [subjects]
    
    with open(output_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        headers = next(reader)  # ヘッダー行
        days_row = next(reader)  # 曜日行
        
        class_schedules = []
        for row in reader:
            if len(row) > 2 and row[0]:
                class_schedules.append(row)
        
        # スケジュールを解析
        days = ["月", "火", "水", "木", "金"]
        for class_idx, class_row in enumerate(class_schedules):
            class_name = class_row[0]
            
            for col_idx in range(1, 31):  # 1-30列が授業
                subject = class_row[col_idx] if col_idx < len(class_row) else ""
                if not subject:
                    continue
                    
                # 曜日と時限を計算
                day_idx = (col_idx - 1) // 6
                period = ((col_idx - 1) % 6) + 1
                day = days[day_idx]
                
                # 日内科目を記録
                daily_subjects[(class_name, day)].append(subject)
    
    # 日内重複を分析
    print("\n=== 日内重複の詳細 ===")
    daily_duplicates = 0
    for (class_name, day), subjects in daily_subjects.items():
        subject_counts = defaultdict(int)
        for subject in subjects:
            subject_counts[subject] += 1
        
        for subject, count in subject_counts.items():
            if count > 1:
                daily_duplicates += 1
                print(f"  {class_name} {day}曜日: {subject}が{count}回")
    
    print(f"\n合計: {daily_duplicates}件の日内重複")
    return daily_duplicates

def main():
    """V3戦略でスケジュール生成してテスト"""
    print("=== 統一ハイブリッド戦略V3のテスト ===")
    
    # 初期化
    path_manager = PathManager()
    csv_repository = CSVRepository(path_manager)
    constraint_loader = ConstraintLoader(path_manager)
    constraint_system = UnifiedConstraintSystem()
    
    # 制約を読み込み
    constraint_loader.load_constraints(constraint_system)
    
    # スケジュール生成
    use_case = GenerateScheduleUseCase(
        csv_repository,
        constraint_system,
        constraint_loader,
        path_manager
    )
    
    request = GenerateScheduleRequest(
        use_advanced_csp=False,
        use_unified_hybrid=True  # V3を使用
    )
    
    result = use_case.execute(request)
    
    print(f"\n✓ スケジュール生成完了")
    print(f"  違反件数: {result.violation_count}")
    
    # 日内重複を分析
    duplicates = analyze_daily_duplicates()
    
    print(f"\n=== 結果サマリー ===")
    print(f"V3戦略による日内重複: {duplicates}件")
    print(f"（V2では28件でした）")
    
    if duplicates < 28:
        print(f"\n✓ 改善成功！ {28 - duplicates}件削減")
    else:
        print(f"\n✗ 改善できませんでした")

if __name__ == "__main__":
    main()